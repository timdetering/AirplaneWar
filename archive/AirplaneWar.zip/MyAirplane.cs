using System;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using DInput=Microsoft.DirectX.DirectInput;
using System.Drawing;

namespace AirplaneWar
{
	/// <summary>
	/// Summary description for MyAirplane.
	/// </summary>
	public class MyAirplane
	{
		airplane myAirplane;
		float weight=500; // 500 kgs
		float rotor=0;
		float mass=0;
		double tailangle=0;
		float wingangleattack=0;

		float m_fPitchVelocity=0;
		float m_fRollVelocity=0;
		float ya=0;


		float liftSpeed=0;

		DInput.Device didev;
		Device d3dDevice;

		Matrix oldView;
		Matrix m_matView;
		public Quaternion rotation=new Quaternion();

		float speed=0;
		float acceleration=0;
		float time=0.05f;
		float gravity=9.81f;
		float supertime=0f;

		public Vector3 m_vVelocity, m_vPosition;

		Vector3 gravityVector;
		Vector3 liftVector;
		Vector3 trustVector;
		Vector3 dragVector;
		Vector3 speedVector;

		Matrix m_matOrientation;

		public MyAirplane(Device d3d, DInput.Device di)
		{
			myAirplane=new airplane(d3d);
			d3dDevice=d3d;
			didev=di;
			rotation = new Quaternion();
			rotation=Quaternion.Identity;

			// the airplane starts with 20� angle (landed)
			rotation.RotateYawPitchRoll(0, -0.34906585f, 0);

			m_matOrientation=new Matrix();
			m_matOrientation.Translate(0, 0, 0);
    
			m_vPosition = new Vector3(0, 0, -10);
			m_vVelocity=new Vector3(0, 0, 0);
			gravityVector=new Vector3(0, 0, 0);
			liftVector=new Vector3(0, 0, 0);
			trustVector=new Vector3(0, 0, 0);
			dragVector=new Vector3(0, 0, 0);
			speedVector=new Vector3(0,0,0);
			mass=weight/gravity;

			m_matView=new Matrix();
			oldView=new Matrix();
		}

		protected void SetupMatrices() 
		{
			Matrix matWorld=new Matrix();
			// The transform Matrix is used to position and orient the objects
			// you are drawing
			// For our world matrix, we will just rotate the object about the y axis.
			Vector3 w=new Vector3(1, 1, 1);

			//	matWorld.RotateAxis(w, Timer / 2);
			//	aplane.SetTransform(matWorld);
			//	b.SetTransform(matWorld);
			
			copymatrix(ref m_matOrientation,ref oldView);

			CamaraTransform();

   
		}

		protected void copymatrix(ref Matrix mat, ref Matrix old) 
		{
			old.M11=mat.M11;
			old.M12=mat.M12;
			old.M13=mat.M13;
			old.M14=mat.M14;
			old.M21=mat.M21;
			old.M22=mat.M22;
			old.M23=mat.M23;
			old.M24=mat.M24;
			old.M31=mat.M31;
			old.M32=mat.M32;
			old.M33=mat.M33;
			old.M34=mat.M34;
			old.M41=mat.M41;
			old.M42=mat.M42;
			old.M43=mat.M43;
			old.M44=mat.M44;
		} 

		protected void CamaraTransform() 
		{

			// Update the position vector
			Vector3 vT=new Vector3(0,0,0), vTemp=new Vector3();
			vT.Add(m_vVelocity);
			m_vPosition.Add(vT);
    

			Quaternion qR=new Quaternion();
			float det=0;

			Matrix matTrans=new Matrix(), matTemp=new Matrix();
			qR.RotateYawPitchRoll(ya, m_fPitchVelocity, m_fRollVelocity);
			rotation=Quaternion.Multiply(qR,rotation);
			/*
						Vector3 vZ = Vector3.Normalize(m_vVelocity);
						Vector3 Up=new Vector3(0,1,0);
						Vector3 vX = Vector3.Cross(Up, vZ);
						Vector3 vY = Vector3.Cross(vZ, vX);
			Matrix lookat = new Matrix();
						lookat.M11=vX.X;
						lookat.M12=vY.X;
						lookat.M13=vZ.X;
						lookat.M14=0;
						lookat.M21=vX.Y;
						lookat.M22=vY.Y;
						lookat.M23=vZ.Y;
						lookat.M24=0;
						lookat.M31=vX.Z;
						lookat.M32=vY.Z;
						lookat.M33=vZ.Z;
						lookat.M34=0;
			*/
			/*		if ((speed>1.94f) && (speed<11.11f))
					{
						Vector3 auxV=Vector3.Normalize(m_vVelocity);
						Vector3 up=new Vector3(0,1,0);
						//	Vector3 side=Vector3.Cross(auxV,up);
						Matrix lookat=Matrix.LookAtLH(new Vector3(0,0,0),auxV,up); 
						Quaternion back=Quaternion.RotationMatrix(lookat);
			
						rotation=Quaternion.Slerp(rotation, back, 0.01f);
					} */

			matTemp=Matrix.RotationQuaternion(rotation);

			//	m_vPosition.y=m_vPosition.y+gravityY;

			matTrans.Translate(m_vPosition.X, m_vPosition.Y, m_vPosition.Z);

			m_matOrientation=Matrix.Multiply(matTemp, matTrans);

	//		Vector3 pos=new Vector3(m_vPosition.X, m_vPosition.Y, m_vPosition.Z-50);
						
	//		m_matView=Matrix.LookAtLH(pos,m_vPosition,new Vector3(0,1,0));

			
			m_matView=Matrix.Invert(ref det,m_matOrientation);

    

			d3dDevice.SetTransform(TransformType.View, m_matView);
		}

		private float GetContactSurface(float height, float width, Vector3 planeNormal) 
		{
			Vector3 airdirection=new Vector3();
			airdirection.X=m_vVelocity.X*(-1);
			airdirection.Y=m_vVelocity.Y*(-1);
			airdirection.Z=m_vVelocity.Z*(-1);
			airdirection.Normalize();
			planeNormal.Normalize();
			float cosangle=Vector3.Dot(airdirection, planeNormal);
			if (Math.Abs(cosangle)<0.017f)
				return 0;
			return height*width*cosangle;
		}

		private float calculateLift(float airdensity) 
		{
			if (m_vVelocity.Length()==0f)
				return 0f;

			Matrix matTemp=new Matrix();
			Vector3 w=new Vector3(1, 0, 0);

			// wings have a 4� on airplane's body
			matTemp=Matrix.RotationAxis(w, -0.069f);

			Vector3 airdirection=new Vector3();
			airdirection.X=m_vVelocity.X*(-1);
			airdirection.Y=m_vVelocity.Y*(-1);
			airdirection.Z=m_vVelocity.Z*(-1);
			airdirection.Normalize();

			Vector3 planeNormal=new Vector3(0,1,0); // plane normal
			// transform it to rotate it on the plane normals
			float aux=airdirection.X;
			planeNormal.TransformNormal(matTemp); // =Vector3.Transform(surfaceX, matTemp);
			planeNormal.TransformNormal(m_matOrientation);
			planeNormal.Normalize();

			float cosangle=Vector3.Dot(airdirection, planeNormal);

			float angleattack=(float)Math.Acos(cosangle);
			angleattack=(float)(angleattack-(Math.PI/2));

			float wingsurface=GetContactSurface(6f, 6f, planeNormal);


			float at14=1.2f; // lift coefficient at 14�
			float liftcoefficient=0;

			float angle=(float)Math.Abs(angleattack);

			if (angle < 0.2443460953f) // 14� 
			{
				liftcoefficient=(angle*at14)/0.2443460953f;  // for wings
			} 
			else if (angle<=0.2792526803f)  // 16�
			{
				liftcoefficient=at14;
			}
			else  // turn around the lift coefficient table (it loses efficiency)
			{
				liftcoefficient=((angle-((angle-0.2443460953f)*2))*at14)/0.2443460953f;
			}

			if (liftcoefficient<0f)
				liftcoefficient=0f;

			wingangleattack=angleattack;

			float lift=((liftcoefficient*airdensity*speed*speed*wingsurface/2));

			return lift;
		}

		private float calculateTailLift(float airdensity) 
		{
			if ((m_vVelocity.Length()==0f) || (speed>16.7f))
				return 0f;

			Vector3 planeNormal=new Vector3(0,1,0); // creates a surface depth
			// transform it to rotate it on the plane normals
			planeNormal.TransformNormal(m_matOrientation);
			planeNormal.Normalize();

			Vector3 airdirection=new Vector3();
			airdirection.X=m_vVelocity.X*(-1);
			airdirection.Y=m_vVelocity.Y*(-1);
			airdirection.Z=m_vVelocity.Z*(-1);
			airdirection.Normalize();
			float cosangle=Vector3.Dot(airdirection, planeNormal);

			float angleattack=(float)Math.Acos(cosangle);

			float wingsurface=GetContactSurface(1f, 1f, planeNormal);

			float at14=1.2f; // lift coefficient at 14�
			float liftcoefficient=0;
			angleattack=(float)(angleattack-(Math.PI/2));
			float angle=(float)Math.Abs(angleattack);

			tailangle=angleattack*180/Math.PI; // attack*(180/Math.PI);
			
			if (Math.Abs(tailangle)<0.2f)
				return 0f;

			if (angle < 0.2443460953f) // 14� 
			{
				liftcoefficient=(angle*at14)/0.2443460953f;  // for wings
			} 
			else if (angle<=0.2792526803f)  // 16�
			{
				liftcoefficient=at14;
			}
			else  // turn around the lift coefficient table (it loses efficiency)
			{
				liftcoefficient=((angle-((angle-0.2443460953f)*2))*at14)/0.2443460953f;
			}

			if (liftcoefficient<0f)
				liftcoefficient=0f;

			float lift=((1*airdensity*speed*speed*wingsurface/2));

			// from that lift, calculate the tail rotation

			// max height of the triangle
			float maxLift=(float)Math.Tan(angleattack)*5;

			float weight=50; // 50 kgs
			float mass=weight/gravity;

	//		Vector3 liftV=new Vector3(0,lift,0);
	//		liftV.TransformNormal(m_matOrientation);

			// from force to distance
			lift=(lift/mass)*time;
			if (Math.Abs(lift)>Math.Abs(maxLift)) 
			{
				if (lift>0)
					lift=angleattack;
				else
					lift=-angleattack;
				return lift;
			}

			lift=(float)Math.Atan(lift/5);

			// return rotation in degrees
			return lift;
		}

		private void doPhysics() 
		{
			if (Form1.focus) 
			{
				// get access to the keyboard
				DInput.KeyboardState state;
				try 
				{
					state=didev.GetCurrentKeyboardState();
				} 
				catch
				{
					didev.Unacquire();
					didev.Acquire();
					state=didev.GetCurrentKeyboardState();
				}


				if (state[DInput.Key.Up]) 
				{
					//	if (m_vPosition.Y>0f)
					m_fPitchVelocity=m_fPitchVelocity+0.02f;
				} 
				else if (state[DInput.Key.Down]) 
				{
					//	if (m_vPosition.Y>0f)
					m_fPitchVelocity=m_fPitchVelocity-0.02f;
				} 
				else 
				{
					m_fPitchVelocity=0;
				} 

				if (state[DInput.Key.D9]) 
				{
					// acceleration for the rotor (propeler)
					acceleration=13.88888f; // around 50km/h in 10 second
				} 
				if (state[DInput.Key.D0]) 
				{
					acceleration=-13.88888f;
				}

				if (state[DInput.Key.Right]) 
				{
					if (m_vPosition.Y<=0f)
						ya=ya+0.01f;
					else
						m_fRollVelocity=m_fRollVelocity-0.01f;
				} 
				else if (state[DInput.Key.Left]) 
				{
					if (m_vPosition.Y<=0f)
						ya=ya-0.01f;
					else
						m_fRollVelocity=m_fRollVelocity+0.01f;
				} 
				else 
				{
					ya=0;
					m_fRollVelocity=0;
				} 
			}

			if (rotor>100f) 
			{ // 97.22222f maximum speed for rotor is 350km/h
				acceleration=0;
				rotor=100f;
			}
			if (rotor<0) 
			{
				acceleration=0;
				rotor=0;
			}


			float airdensity=1;
			airdensity -= m_vPosition.Y/10000f;
			if (airdensity<0)
				airdensity=0;

			// get the vertical speed (lift)

			liftVector.Y=calculateLift(airdensity);
			float tailLift=calculateTailLift(airdensity);

			m_fPitchVelocity+=tailLift;

			float groundfriction=1f;
			float curvefriction=1f;

			if (m_vPosition.Y<=10f) 
			{ // at ground it takes a while to gain speed and stop faster
				airdensity=2;
				if (m_vPosition.Y<=0f) 
				{
					groundfriction=1.5f;
					curvefriction=10f;
				}
			}

			// apply drag (frontal drag produced by air)
			float dragcoefficient=0.05f;  // for frontal surface
			
			Vector3 normal=new Vector3(0,0,1);
			normal.TransformNormal(m_matOrientation);
			float frontsurface=GetContactSurface(2f, 2f, normal);

			float dragZ=((groundfriction*dragcoefficient*airdensity*speed*speed*frontsurface/2));
			dragVector.Z=dragZ;



			// apply drag (lateral drag produced by air)
			dragcoefficient=0.2f;  // for frontal surface

			normal=new Vector3(1,0,0);
			normal.TransformNormal(m_matOrientation);
			frontsurface=GetContactSurface(4f,4f,normal);

			dragZ=(((groundfriction*groundfriction*curvefriction)*dragcoefficient*airdensity*speed*speed*frontsurface/2));

			dragVector.X=dragZ;

			// apply drag produced by the bottom surface against air
			dragcoefficient=0.2f;  // for frontal surface

			normal=new Vector3(0,1,0);
			normal.TransformNormal(m_matOrientation);
			frontsurface=GetContactSurface(4f,4f,normal);
			dragZ=((dragcoefficient*airdensity*speed*speed*frontsurface/2));
			dragVector.Y=dragZ;

			// apply engine trust (not sure about this formula)
			frontsurface=5f;
			float trustcoefficient=0.05f;  // for airplanes
			float trustZ=((trustcoefficient*airdensity*rotor*20*frontsurface/2));
			trustVector.Z=trustZ;

			rotor = rotor + acceleration*time;


			Vector3 accelerationVector=new Vector3(0,0,0);

			// we do all calculus on the local coordenates
			accelerationVector=Vector3.Add(trustVector, liftVector);
			accelerationVector.Add(dragVector);

			accelerationVector.TransformNormal(m_matOrientation);

			// gravity
			gravityVector.Y=-(weight);
			accelerationVector.Add(gravityVector);


			// we have all the forces added up, now we find the acceleration
			// by dividing by the mass, remember: Force = Acceleration * Mass
			accelerationVector.X=accelerationVector.X/mass;
			accelerationVector.Y=accelerationVector.Y/mass;
			accelerationVector.Z=accelerationVector.Z/mass;
 

			// find the velocity (speed and direction)
			// formula: v = v0 + at
			m_vVelocity.X=m_vVelocity.X+accelerationVector.X*(time);
			m_vVelocity.Y=m_vVelocity.Y+accelerationVector.Y*(time);
			if (m_vPosition.Y<=0f) 
			{
				m_vPosition.Y=0f;
				if (m_vVelocity.Y<0f) 
				{
					m_vVelocity.Y=0f;
				}
			}
			m_vVelocity.Z=m_vVelocity.Z+accelerationVector.Z*(time);

			speed=m_vVelocity.Length();

			supertime+=time;

		}

		public void Render(System.Drawing.Font font) 
		{
			doPhysics();

			// Setup the world, view, and projection matrices
			SetupMatrices();
			
		//	myAirplane.Render(m_matOrientation);

			Rectangle rect=new Rectangle(10,20,300,100);
			Microsoft.DirectX.Direct3D.Font d3dxfont=new Microsoft.DirectX.Direct3D.Font(d3dDevice,font);
			d3dxfont.DrawText("Tiempo: "+supertime, rect, DrawTextFormat.None, Color.AntiqueWhite);
			rect.Y=30;
			d3dxfont.DrawText("Speed: "+(speed*60*60)/1000, rect, DrawTextFormat.None, Color.AntiqueWhite);
			rect.Y=40;
			d3dxfont.DrawText("Height: "+m_vPosition.Y, rect, DrawTextFormat.None, Color.AntiqueWhite);
			rect.Y=50;
			d3dxfont.DrawText("Wing: "+wingangleattack*(180/Math.PI)+"  Tail: "+tailangle, rect, DrawTextFormat.None, Color.AntiqueWhite);

			//		d3dx8.DrawText(d3dxfont, unchecked((int)0xFF00FFFF), "GraSpeed: "+gravitySpeed, ref rect, 0);
			rect.Y=60;
			d3dxfont.DrawText("LiftSpeed: "+liftSpeed, rect, DrawTextFormat.None, Color.AntiqueWhite);
			rect.Y=70;
			//		d3dx8.DrawText(d3dxfont, unchecked((int)0xFF00FFFF), "Distancia: "+m_vVelocity.z/0.03, ref rect, 0);
			rect.Y=80;
			d3dxfont.DrawText("Rotor: "+rotor, rect, DrawTextFormat.None, Color.AntiqueWhite);

		
		}
	}
}
