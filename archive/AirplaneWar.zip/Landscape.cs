using System;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace AirplaneWar
{
	/// <summary>
	/// Summary description for Box.
	/// </summary>
	public class Landscape : MyMesh
	{
		public Vector3 min;
		public Vector3 max;

		public Landscape(Device d3device):base(d3device)
		{
			ExtendedMaterial[] materials=null;

			GraphicsStream o;
			mesh = Mesh.FromFile("terreno.x",MeshFlags.SystemMemory, d3dDevice, out o, out materials);
			mesh.OptimizeInPlace(MeshFlags.OptimizeCompact | MeshFlags.OptimizeAttrSort | MeshFlags.OptimizeVertexCache, o);


			//	Before getting this information from the material buffer, the material and texture arrays must be resized to fit all the materials and textures for this mesh.
			MeshMaterials=new Material[materials.Length]; // Mesh Material data
			MeshTextures=new Texture[materials.Length];  // ' Mesh Textures

			GraphicsStream g=mesh.LockVertexBuffer(LockFlags.ReadOnly);
			Geometry.ComputeBoundingBox(g,mesh.NumberVertices, mesh.VertexFormat, out min,out max);
			mesh.UnlockVertexBuffer();
			g.Close();
			g=null;

			int i;
			for(i = 0;i<materials.Length;i++) 
			{
    
				// Copy the material using the d3dx helper function
				MeshMaterials[i]=materials[i].Material3D;

				// Set the ambient color for the material (D3DX does not do this)
				MeshMaterials[i].Ambient = MeshMaterials[i].Diffuse;
     
				// Create the texture
				string strTexName = materials[i].TextureFilename;
				if ((strTexName!=null) && (strTexName != "")) 
				{
					MeshTextures[i]=TextureLoader.FromFile(d3dDevice, strTexName);

	//				MeshTextures[i]=TextureLoader.FromFile(d3dDevice, strTexName, 256, 256,1, Usage.SoftwareProcessing, Format.X8R8G8B8, Pool.Default, Filter.Dither, Filter.None, unchecked((int)0xFFFFFFFF));
				} 
			}

			// Set the FVF to a reasonable type
	/*		SetFVF(mesh.VertexFormat | VertexFormats.Normal | VertexFormats.Texture1 );

			// Gain access to the model's vertices
			VertexBuffer pVB=mesh.VertexBuffer;
			int dwNumVertices = mesh.NumberVertices;

					CustomVertex.PositionNormalTextured [] dest=(CustomVertex.PositionNormalTextured[])pVB.Lock(0,0);

					for(int x=0; x<dwNumVertices; x++ )
					{
						dest[x].Y=1;
				//		pVertices[i].p.x *= 0.1f;
				//		pVertices[i].p.z *= 0.1f;
						//	pVertices[i].p.y = HeightField( pVertices[i].p.x, pVertices[i].p.z );
					}

					// Done with the vertex buffer
					pVB.Unlock(); */
			o.Close();
			o=null;
		}

		public void SetFVF(VertexFormats fvf) 
		{
			mesh=mesh.Clone(MeshFlags.SystemMemory, fvf, d3dDevice);
			mesh.ComputeNormals();
		}

		public void SetTransform(Matrix mat) 
		{
			matWorld=mat;
		}

		public void ApplyTransform() 
		{
			// The transform Matrix is used to position and orient the objects
			// you are drawing
			// For our world matrix, we will just rotate the object about the y axis.
			Vector3 w=new Vector3(0, 0, 0);

			matWorld=Matrix.RotationAxis(w, 0);
			d3dDevice.SetTransform(TransformType.World, matWorld);
		}

		public void Render() 
		{
			ApplyTransform();
			// yellow material
/*			D3DMATERIAL8 mtrl=new D3DMATERIAL8();
			D3DCOLORVALUE col=new D3DCOLORVALUE();
			col.r=1;
			col.g=1;
			col.b=0;
			col.a=1;
			mtrl.diffuse = col;
			mtrl.ambient = col;
			d3dDevice.SetMaterial(ref mtrl);


			mesh.DrawSubset(0); */

			// Meshes are divided into subsets, one for each material.
			// Render them in a loop

			for (int i = 0;i<MeshMaterials.Length;i++) 
			{
    
				// Set the material and texture for this subset
				d3dDevice.Material= MeshMaterials[i];
				d3dDevice.SetTexture(0, MeshTextures[i]);
				d3dDevice.SamplerState[0].MinFilter=TextureFilter.Linear;
				d3dDevice.SamplerState[0].MagFilter=TextureFilter.Linear;
        
				// Draw the mesh subset
				mesh.DrawSubset(i);
			}
		}
	}
}
