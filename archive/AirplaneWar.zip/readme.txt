Airplane War 0.1
copyright Joaquin Grech (creative1@bigfoot.com)
http://www.bocazas.com/airplanewar

----------------

To this day (December 21th 2002), this is a very basic flight simulator designed in c# and
directx 9 which was released yesterday.

It is expected to be buggy but has enough information to allow you to learn about the new
directx 9 managed code.

Please check the website http://www.bocazas.com/airplanewar for updates or if you want
to help in future releases. We really need help for future releases, specially graphics
and 3d designers :)


Airplane Controls:
------------------

0 to turn off engine
9 to turn on and full speed engine

Arrow keys to move around.