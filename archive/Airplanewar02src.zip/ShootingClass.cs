using System;
using System.Collections;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace AirplaneWar
{
	/// <summary>
	/// Summary description for ShootingClass.
	/// </summary>
	public class ShootingClass
	{
		shot gunshot=null;
		Hashtable Directions=new Hashtable();

		public ShootingClass(Device d3dDevice)
		{
			gunshot=new shot(d3dDevice);
		}
		public void Render() 
		{
			foreach (DictionaryEntry en in Directions) 
			{
				Vector3 pos=(Vector3)gunshot.Positions[en.Key];
				Vector3 speedV=(Vector3)en.Value;
				pos.Add(speedV);
				gunshot.Positions[en.Key]=pos;
			} 

			gunshot.Render();
		}
		public void NewShot(float x, float y, float z, Vector3 direction) 
		{
			Vector3 pos=new Vector3(x,y,z);
			int id=Directions.Count;
		    Directions[id]=direction;
			gunshot.Directions[id]=direction;
			gunshot.Positions[id]=pos;
		}
	}
}
