using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
// using DInput=Microsoft.DirectX.DirectInput;
using DPlay=Microsoft.DirectX.DirectPlay;

namespace AirplaneWar
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
	//	private DInput.Device didev;
		private Device d3dDevice;
		private DPlay.Client dpc=null;
		private DPlay.Server dps=null;
		public static bool focus=false;
		public static string hoststring=null;
		bool connected=false;
		int playerId=0;

		Landscape landscape;
		airplane aplane;
		MyAirplane myAirplane;

		Sprite sp;
		Rectangle maprect,pointrect;
		Texture map,point;

		private System.Timers.Timer timer1;


		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.Show();

			InitD3D();

			Dplay dialog=new Dplay();
			if (dialog.ShowDialog(this)==DialogResult.OK) 
			{
				StartServer();
			}
			else 
			{
				InitDirectPlay();
			}

			sp=new Sprite(d3dDevice);
			maprect=new Rectangle(0,0,128,128);
			map=TextureLoader.FromFile(d3dDevice,@"media\map.jpg");
			pointrect=new Rectangle(0,0,5,5);
			point=TextureLoader.FromFile(d3dDevice,@"media\point.jpg");

			// init objects geometry
			landscape=new Landscape(d3dDevice);
			myAirplane=new MyAirplane(d3dDevice,landscape);
			aplane=new airplane(d3dDevice);

			myAirplane.m_vPosition.Y=myAirplane.m_vPosition.Y-landscape.Intersect(myAirplane.m_vPosition, new Vector3(0f,-1f,0f))+1.1f;
			myAirplane.prepos=myAirplane.m_vPosition;

			timer1.Start();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		protected void InitDirectPlay() 
		{
			// create a direct play connection
			dpc=new DPlay.Client();

			DPlay.ApplicationDescription appdesc=new DPlay.ApplicationDescription();
			appdesc.GuidApplication=new Guid("B32DD425-DB33-4f9c-972F-C68269C409F6");

			DPlay.Address dpa=new DPlay.Address(hoststring,895);
			DPlay.Address dpdi=new DPlay.Address();

			dpdi.ServiceProvider=DPlay.Address.ServiceProviderTcpIp;

			// Set up our event handlers
			dpc.ConnectComplete+=new DPlay.ConnectCompleteEventHandler(this.ConnectComplete);

	//		dpc.ConnectComplete += new ConnectCompleteEventHandler(this.ConnectComplete);
			dpc.Receive += new DPlay.ReceiveEventHandler(this.DataReceivedMsg);
	//		dpc.SessionTerminated += new SessionTerminatedEventHandler(this.SessionLost);

			dpc.Connect(appdesc,dpa,dpdi, null, 0);

		}

		protected void StartServer() 
		{
			// create a direct play server connection
			dps = new DPlay.Server();
			DPlay.ApplicationDescription appdesc=new DPlay.ApplicationDescription();
			appdesc.GuidApplication=new Guid("B32DD425-DB33-4f9c-972F-C68269C409F6");
			appdesc.MaxPlayers=0;
			appdesc.SessionName="AWarServer";
			appdesc.Flags=DPlay.SessionFlags.ClientServer | DPlay.SessionFlags.NoDpnServer;

			DPlay.Address dpa=new DPlay.Address("localhost",895);

			// Add our event handlers
	//		dps.PlayerDestroyed += new PlayerDestroyedEventHandler(this.DestroyPlayerMsg);
	//		dps.Receive += new DPlay.ReceiveEventHandler(this.Receive);

	//		dps.Receive+=new DPlay.ReceiveEventHandler(this.Receive);
	//		dps.IndicateConnect+=new DPlay.IndicateConnectEventHandler(this.ConnectComplete);

			dps.Receive += new DPlay.ReceiveEventHandler(this.DataReceivedMsg);

			dps.Host(appdesc,dpa);

		}

		protected void InitJoystick() 
		{

		}

		protected void InitD3D() 
		{
			// create direct input device to keyboard
	/*		didev=new DInput.Device(DInput.SystemGuid.Keyboard);
			didev.SetCooperativeLevel(this,DInput.CooperativeLevelFlags.NonExclusive | DInput.CooperativeLevelFlags.Foreground);

			// acquire access
			didev.Acquire(); */


			// get current screen mode
	//		AdapterInformation adapterInfo = Manager.Adapters[0];
	//		DisplayMode mode=adapterInfo.CurrentDisplayMode;

			// direct 3d parameters
			PresentParameters d3dpp=new PresentParameters();
			d3dpp.Windowed = true;
			d3dpp.SwapEffect = SwapEffect.Copy;
			d3dpp.EnableAutoDepthStencil = true;
			d3dpp.AutoDepthStencilFormat = DepthFormat.D24S8;
	//		d3dpp.BackBufferFormat = ((AdapterInformation)Manager.Adapters[0]).CurrentDisplayMode.Format;
	//		d3dpp.BackBufferCount = 1;

	/*		d3dpp.BackBufferWidth  = ourRenderTarget.ClientRectangle.Right - ourRenderTarget.ClientRectangle.Left;
			d3dpp.BackBufferHeight = ourRenderTarget.ClientRectangle.Bottom - ourRenderTarget.ClientRectangle.Top;
			d3dpp.BackBufferFormat = graphicsSettings.DeviceCombo.BackBufferFormat;
			d3dpp.FullScreenRefreshRateInHz = 0;
			d3dpp.PresentationInterval = PresentInterval.Immediate;
			d3dpp.DeviceWindow = ourRenderTarget; */
			
			// create the direct3d device
			d3dDevice = new Device(0, DeviceType.Hardware, this, CreateFlags.SoftwareVertexProcessing, d3dpp);

			// Setup the event handlers for our device
		//	d3dDevice.DeviceLost += new System.EventHandler(this.InvalidateDeviceObjects);
			d3dDevice.DeviceReset += new System.EventHandler(this.RestoreDeviceObjects);
		//	d3dDevice.Disposing += new System.EventHandler(this.DeleteDeviceObjects);
		//	d3dDevice.DeviceResizing += new System.ComponentModel.CancelEventHandler(this.EnvironmentResized);

			RestoreDeviceObjects(null,null);

		}

		protected void RestoreDeviceObjects(System.Object sender, System.EventArgs e)
		{
			// Turn on the zbuffer
			d3dDevice.RenderState.ZBufferEnable=true;
    
			// prepare light

			d3dDevice.Lights[0].Type=LightType.Directional;
			d3dDevice.Lights[0].Diffuse=Color.FromArgb(0, Color.White);

			d3dDevice.Lights[0].Direction=new Vector3(1,-10,1);
			d3dDevice.Lights[0].Enabled=true;
			d3dDevice.Lights[0].Commit();

			// Turn on lighting
			d3dDevice.RenderState.Lighting=true;

			// Turn on full ambient light to white
			d3dDevice.RenderState.Ambient=Color.White;

			// prepare camara
			CamaraLen();
		}


		protected void CamaraLen() 
		{
			// The projection matrix describes the camera's lenses
			// For the projection matrix, we set up a perspective transform (which
			// transforms geometry from 3D view space to 2D viewport space, with
			// a perspective divide making objects smaller in the distance). To build
			// a perpsective transform, we need the field of view (1/4 pi is common),
			// the aspect ratio, and the near and far clipping planes (which define at
			// what distances geometry should be no longer be rendered).
			Matrix matProj=Matrix.PerspectiveFovLH((float)3.14159 / 4, 1, 1, 10000000);
			d3dDevice.SetTransform(TransformType.Projection, matProj);
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				// release keyboard
		//		didev.Unacquire();
		/*		if (dpc!=null) 
				{
					dpc.UnRegisterMessageHandler();
					dpc.Close(0);
				} */

			/*	if (dps!=null) 
				{
					dps.Dispose(true);
				}  */

				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.timer1 = new System.Timers.Timer();
			((System.ComponentModel.ISupportInitialize)(this.timer1)).BeginInit();
			// 
			// timer1
			// 
			this.timer1.Interval = 50;
			this.timer1.SynchronizingObject = this;
			this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(this.timer1_Elapsed);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(792, 573);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Deactivate += new System.EventHandler(this.Form1_Deactivate);
			((System.ComponentModel.ISupportInitialize)(this.timer1)).EndInit();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			// Make sure the UI is responsive
		//	this.Invoke(new DoEventsCallback(this.ProcessMessages));

			// rendering

			// clear the rectangle
			d3dDevice.Clear(ClearFlags.Target | ClearFlags.ZBuffer,Color.Blue, 1, 0);

			// Begin the scene.
			d3dDevice.BeginScene();

			focus=this.Focused;
			myAirplane.height=landscape.Intersect(myAirplane.m_vPosition, new Vector3(0f,-1f,0f));
			myAirplane.realheight=landscape.RealHeight(myAirplane.m_vPosition);
			myAirplane.Render(this.Font);

			aplane.Render();
			landscape.Render();

			sp.Begin();
			int mapy=this.Height-158;
			sp.Draw(map, maprect, new Vector2(1,1), new Vector2(0,0), 0f, new Vector2(0,mapy), unchecked((int)0xFFFFFFFF));
			int pointx=(int)((myAirplane.m_vPosition.X+100000)*128/200000);
			int pointy=(int)((-myAirplane.m_vPosition.Z+100000)*128/200000)+mapy;

			sp.Draw(point, pointrect, new Vector2(1,1), new Vector2(0,0), 0f, new Vector2(pointx,pointy), unchecked((int)0xFFFFFFFF));

			sp.End();

			sendMessage();

			// End the scene.
			d3dDevice.EndScene();

			// copy the render to the window
			d3dDevice.Present();

			Application.DoEvents();

		}

		protected void sendMessage() 
		{
				if (dpc!=null) 
				{
					if (connected) 
					{
						DPlay.NetworkPacket stm=new DPlay.NetworkPacket();
						Quaternion qr=Quaternion.Normalize(myAirplane.rotation);
						stm.Write(MessageType.SendMessage);
						stm.Write(myAirplane.m_vPosition.X);
						stm.Write(myAirplane.m_vPosition.Y);
						stm.Write(myAirplane.m_vPosition.Z);
						stm.Write(qr.X);
						stm.Write(qr.Y);
						stm.Write(qr.Z);
						stm.Write(qr.W);
						dpc.Send(stm,0,DPlay.SendFlags.NoLoopback | DPlay.SendFlags.NonSequential | DPlay.SendFlags.Coalesce | DPlay.SendFlags.NoComplete);
					}
				} 
				else 
				{
					if (playerId!=0) 
					{
						DPlay.NetworkPacket stm=new DPlay.NetworkPacket();
						Quaternion qr=Quaternion.Normalize(myAirplane.rotation);
						stm.Write(MessageType.SendMessage);
						stm.Write(myAirplane.m_vPosition.X);
						stm.Write(myAirplane.m_vPosition.Y);
						stm.Write(myAirplane.m_vPosition.Z);
						stm.Write(qr.X);
						stm.Write(qr.Y);
						stm.Write(qr.Z);
						stm.Write(qr.W);
						dps.SendTo(playerId,stm,0,DPlay.SendFlags.NoLoopback | DPlay.SendFlags.NonSequential | DPlay.SendFlags.Coalesce | DPlay.SendFlags.NoComplete);
					}
				}
		}

		public enum MessageType
		{
			//Messages
			SendMessage , //Send a message to someone
		}

		void ConnectComplete(object sender, DPlay.ConnectCompleteEventArgs e)
		{
			connected=true;
		}

		void DataReceivedMsg(object sender, DPlay.ReceiveEventArgs e)
		{
			// We've received data, process it

			MessageType msg = (MessageType)e.Message.ReceiveData.Read(typeof(MessageType));
			switch (msg)
			{
				case MessageType.SendMessage:
					playerId=e.Message.SenderID;
					float x=(float)e.Message.ReceiveData.Read(typeof(float));
					float y=(float)e.Message.ReceiveData.Read(typeof(float));
					float z=(float)e.Message.ReceiveData.Read(typeof(float));
					float x2=(float)e.Message.ReceiveData.Read(typeof(float));
					float y2=(float)e.Message.ReceiveData.Read(typeof(float));
					float z2=(float)e.Message.ReceiveData.Read(typeof(float));
					float w=(float)e.Message.ReceiveData.Read(typeof(float));
					aplane.Translate(playerId,x,y,z,x2,y2,z2,w);
					break;
			}
			e.Message.ReceiveData.Dispose(); // Don't need the data anymore
		}

		private void Form1_Deactivate(object sender, System.EventArgs e)
		{
			focus=false;
		}
	}
}
